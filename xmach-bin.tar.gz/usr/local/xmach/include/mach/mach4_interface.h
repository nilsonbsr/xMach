#ifndef	_mach4_user_
#define	_mach4_user_

/* Module mach4 */

#include <mach/kern_return.h>
#include <mach/port.h>
#include <mach/message.h>

#include <mach/std_types.h>
#include <mach/mach_types.h>

#endif	/* not defined(_mach4_user_) */
