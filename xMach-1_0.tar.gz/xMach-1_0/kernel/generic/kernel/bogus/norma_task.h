#define NORMA_TASK 0
