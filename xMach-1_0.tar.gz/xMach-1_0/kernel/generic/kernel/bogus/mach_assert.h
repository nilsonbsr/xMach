#ifdef	DEBUG
#define MACH_ASSERT 1
#else
#define MACH_ASSERT 0
#endif
