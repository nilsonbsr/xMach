#define NORMA_ETHER 0
