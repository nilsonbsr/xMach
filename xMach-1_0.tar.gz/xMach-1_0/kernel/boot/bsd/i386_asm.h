











#define TSS_ESP0 4

#define TSS_SS 80

#define TSS_SIZE 104

#define KERNEL_CS 8

#define KERNEL_DS 16

#define KERNEL_16_CS 24

#define KERNEL_16_DS 32

#define LINEAR_CS 40

#define LINEAR_DS 48







