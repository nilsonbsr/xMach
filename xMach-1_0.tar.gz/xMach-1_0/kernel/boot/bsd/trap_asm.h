











#define TR_EDI 16

#define TR_ESI 20

#define TR_EBP 24

#define TR_EBX 32

#define TR_EDX 36

#define TR_ECX 40

#define TR_EAX 44

#define TR_TRAPNO 48

#define TR_ERR 52

#define TR_EIP 56

#define TR_CS 60

#define TR_EFLAGS 64

#define TR_ESP 68

#define TR_SS 72

#define TR_V86_ES 76

#define TR_V86_DS 80

#define TR_V86_FS 84

#define TR_V86_GS 88

#define TR_KSIZE 68

#define TR_USIZE 76

#define TR_V86SIZE 92







