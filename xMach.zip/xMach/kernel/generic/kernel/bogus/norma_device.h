#define NORMA_DEVICE 0
