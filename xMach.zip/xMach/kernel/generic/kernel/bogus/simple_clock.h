#define SIMPLE_CLOCK 0
