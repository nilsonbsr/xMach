#define NORMA_IPC 0 /* can no longer be turned on */
