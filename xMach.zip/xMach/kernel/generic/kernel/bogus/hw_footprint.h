#define HW_FOOTPRINT 0
