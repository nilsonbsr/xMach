#define NORMA_VM 0
