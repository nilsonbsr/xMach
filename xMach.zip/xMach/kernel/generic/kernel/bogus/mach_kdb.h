#ifdef	DEBUG
#define MACH_KDB 1
#else
#define MACH_KDB 0
#endif
