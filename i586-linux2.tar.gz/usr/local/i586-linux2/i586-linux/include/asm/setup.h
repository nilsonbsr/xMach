/*
 *	Just a place holder. We don't want to have to test x86 before
 *	we include stuff
 */